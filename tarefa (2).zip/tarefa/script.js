
let marcas = []; // Guarda as marcas recebidas da API para usar depois

// Busca todas as marcas de carros
async function buscarMarcas() {

    // Faz uma requisição à API e aguarda a resposta
    const resposta = await fetch(
        "https://brasilapi.com.br/api/fipe/marcas/v1/carros"
    );

    // Converte a resposta em JSON e guarda as marcas
    marcas = await resposta.json();

    // Encontra a lista de sugestões no HTML
    const lista = document.getElementById("listaMarcas");

    // Limpa a lista para não repetir as marcas
    lista.innerHTML = "";

    // Percorre todas as marcas e adiciona seus nomes à lista
    marcas.forEach(function (marca) {
        lista.innerHTML +=
            "<option value='" + marca.nome + "'>";
    });
}


// Busca os modelos da marca escolhida.
async function buscarModelos() {

    // Pega o nome digitado pelo usuário.
    const nomeDigitado = document.getElementById("pesquisaMarca").value;

    // Procura a marca digitada dentro da lista de marcas.
    const marcaEncontrada = marcas.find(function (marca) {

        // Compara os nomes ignorando letras maiúsculas e minúsculas.
        return marca.nome.toLowerCase() === nomeDigitado.toLowerCase();
    });

    // Se a marca não existir, mostra um aviso e encerra a função.
    if (!marcaEncontrada) {
        alert("Selecione uma marca válida da lista!");
        return;
    }

    // Guarda o código da marca no elemento HTML "resultado".
    document.getElementById("resultado").value = marcaEncontrada.valor;

    // Armazena o código da marca para consultar seus modelos.
    const marca = marcaEncontrada.valor;

    // Faz a requisição dos modelos da marca selecionada.
    const resposta = await fetch(
        "https://brasilapi.com.br/api/fipe/veiculos/v1/carros/" + marca
    );

    // Converte a resposta da API em uma lista de modelos.
    const modelos = await resposta.json();

    // Encontra o campo onde os modelos serão exibidos.
    const caixaModelos = document.getElementById("modelos");

    // Apaga os modelos anteriores.
    caixaModelos.innerHTML = "";

    // Adiciona cada modelo como uma opção do select.
    // O value guarda o código e o texto mostra o nome.
    modelos.forEach(function (modelo) {
        caixaModelos.innerHTML +=
            "<option value='" + modelo.valor + "'>" +
            modelo.modelo + "</option>";
    });
}


// Busca os anos disponíveis para o modelo escolhido.
async function buscarAnos() {

    // Pega o código da marca selecionada.
    const marca = document.getElementById("resultado").value;

    // Pega o código do modelo selecionado.
    const modelo = document.getElementById("modelos").value;

    // Mostra os códigos no console para ajudar nos testes.
    console.log("Marca:", marca);
    console.log("Modelo:", modelo);

    // Consulta os anos usando os códigos da marca e do modelo.
    const resposta = await fetch(
        "https://brasilapi.com.br/api/fipe/anos/v1/carros/" + marca + "/" + modelo
    );

    // Verifica se a API retornou algum erro HTTP.
    if (!resposta.ok) {
        console.log("Erro na API:", resposta.status);
        return;
    }

    // Converte a resposta em uma lista de anos.
    const anos = await resposta.json();

    // Encontra o campo dos anos no HTML.
    const caixaAnos = document.getElementById("anos");

    // Limpa os anos anteriores.
    caixaAnos.innerHTML = "";

    // Adiciona os anos disponíveis ao select.
    anos.forEach(function (ano) {
        caixaAnos.innerHTML +=
            "<option value='" + ano.valor + "'>" +
            ano.nome + "</option>";
    });
}


// Consulta o valor FIPE do veículo selecionado.
async function consultarPreco() {

    // Pega os códigos da marca, do modelo e do ano.
    const marca = document.getElementById("resultado").value;
    const modelo = document.getElementById("modelos").value;
    const ano = document.getElementById("anos").value;

    // Verifica se algum dos campos está vazio.
    // O símbolo ! significa "não" e || significa "ou".
    if (!marca || !modelo || !ano) {
        alert("Selecione marca, modelo e ano!");
        return;
    }

    // Consulta os detalhes do veículo na API.
    const resposta = await fetch(
        "https://brasilapi.com.br/api/fipe/detalhes/v1/carros/" +
        marca + "/" + modelo + "/" + ano
    );

    // Se a consulta retornar um erro HTTP, avisa o usuário.
    if (!resposta.ok) {
        alert("Erro ao consultar preço!");
        return;
    }

    // Converte a resposta em um objeto JavaScript.
    const dados = await resposta.json();

    // Mostra os dados recebidos no console.
    console.log(dados);

    // Exibe o valor FIPE na página HTML.
    document.getElementById("preco").innerText =
        "valor FIPE: " + dados.valor;
}
